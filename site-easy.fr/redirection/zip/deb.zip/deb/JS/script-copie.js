$(function(){
	$('.click').click(function(){
		$('.wrapper1').slideDown(2000, function(){
			$('.click').hide();
		});	
	});
});